﻿Imports System.Xml
Imports System.IO
Imports System.Xml.Serialization
Imports System.Linq
Imports System.Security.Cryptography.X509Certificates
Imports DocumentFormat.OpenXml.Wordprocessing
Imports SAP2000v1
Imports System.Windows.Interop

Public Class SAP2000_Class
    Public Frames() As Frame_
    Public Points() As Point_
    Public Stories() As Story_
    Public Groups() As Group_
    Public SteelFrameDesignGroupIDs As List(Of Integer)
    Public SapModel As SAP2000v1.cSapModel
    Public SAP2000Object As SAP2000v1.cOAPI = Nothing
    Public WSections As IEnumerable(Of STEEL_I_SECTION)
    Public PIPESections As IEnumerable(Of STEEL_PIPE)
    Public HSSSections As IEnumerable(Of STEEL_PIPE)
    Public FormInfo As FormInfo_
    Public ComboNames As Combinations_
    Public ret As Integer
    Public StructureHeight As Double
    Public TopDriftX As Double
    Public TopDriftY As Double
    Public TopDriftLimit As Double
    Public Ub() As Integer
    Public Lb() As Integer
    Public StructureWeight As Double
    Public SectionPropertyData As String
    Public Iter As Integer
    Public A992Fy50Weight As Double
    Public SAP2000_print As SAP2000_Print
    Public Sub New(ByRef FormInfo_ As FormInfo_)
        SAP2000_print = New SAP2000_Print
        FormInfo = FormInfo_
        Call Initilize()
    End Sub
    Public Sub Close()
        'Close SAP2000
        SAP2000Object.ApplicationExit(False)

        'Clean up variables
        SapModel = Nothing
        SAP2000Object = Nothing
        'Check ret value 
        If ret = 0 Then
            MsgBox("API script completed successfully.")
        Else
            MsgBox("API script FAILED to complete. Please see error log file in the Sap2000 file directory")
        End If
    End Sub
    Protected Overrides Sub Finalize()
        Console.WriteLine("An Instance of class destroyed")
    End Sub
    Private Function Initilize()
        ret = InitilizeSAP2000()
        Dim sw As New StreamWriter(Path.GetDirectoryName(FormInfo.FileList.SAP2000File) & "\ErrorLog.txt", False)
        sw.WriteLine("Error messages")
        sw.Close()
        If (ret <> 0) Then : errorlogprint("Problem occured on Function: InitilizeSAP2000") : Return ret : Exit Function : End If
        ret = InitilizePoints()
        If (ret <> 0) Then : errorlogprint("Problem occured on Function: InitilizePoints") : Return ret : Exit Function : End If
        ret = InitilizeFrames()
        If (ret <> 0) Then : errorlogprint("Problem occured on Function: InitilizeFrames") : Return ret : Exit Function : End If

        ret = InitilizeGroups()
        If (ret <> 0) Then : errorlogprint("Problem occured on Function: InitilizeGroups") : Return ret : Exit Function : End If
        ret = InitilizeLoadCases()
        If (ret <> 0) Then : errorlogprint("Problem occured on Function: InitilizeLoadCases") : Return ret : Exit Function : End If
        ret = InitilizeSections()
        If (ret <> 0) Then : errorlogprint("Problem occured on Function: InitilizeSections") : Return ret : Exit Function : End If
        '_____________________________________________________
        'Upper Lower boundary Def
        If FormInfo.CheckStructure = False Then Initilize_UBLB()
        '_____________________________________________________
        'Start Timer
        FormInfo.TimerInfo.startDate = Date.Now
        FormInfo.TimerInfo.StartTime = TimeOfDay.ToString("hh:mm:ss")        'Start Time @ textbox 10
        Return Nothing
    End Function
    Private Function InitilizeSAP2000() As Integer
        Dim SapFileName As String = FormInfo.FileList.SAP2000File
        'set the following flag to true to attach to a running instance of the program 
        'otherwise a new instance of the program will be started Steel
        Dim AttachToInstance As Boolean = False

        'full path to the program executable set it to the installation folder 
        'Note, the path below may need to be modified if you have SAP2000 installed in a different location 
        Dim ProgramPath As String = System.IO.Path.Combine(System.Environment.GetEnvironmentVariable("PROGRAMFILES"), "Computers and Structures", "SAP2000 23", "SAP2000.exe")
        ProgramPath = ProgramPath.Replace("Program Files (x86)", "Program Files")
        If File.Exists(ProgramPath) = False Then
            Dim openFileDialog1 As New Windows.Forms.OpenFileDialog With {
                .Filter = "SAP2000 exe File|*.exe",
                .Title = "Select SAP2000 exe file"
                 }
            openFileDialog1.ShowDialog()
            ProgramPath = openFileDialog1.FileName.ToString
        End If

        SectionPropertyData = Path.GetDirectoryName(ProgramPath) & "\Property Libraries\Sections\AISC14M.xml"
        If File.Exists(SectionPropertyData) = False Then
            Dim openFileDialog1 As New Windows.Forms.OpenFileDialog With {
                .Filter = "Section property data File|*.xml",
                .Title = "Select section property data file"
                 }
            openFileDialog1.ShowDialog()
            SectionPropertyData = openFileDialog1.FileName.ToString
        End If

        If AttachToInstance Then
            'attach to a running instance of SAP2000 
            Try
                'get the active SAP2000 object
                SAP2000Object = DirectCast(System.Runtime.InteropServices.Marshal.GetActiveObject("CSI.SAP2000.API.SapObject"), SAP2000v1.cOAPI)
            Catch ex As Exception
                MsgBox("No running instance of the program found or failed to attach.")
                ret = -1 : Return ret
            End Try
        Else
            'create a new instance of SAP2000 
            Try

                'create API helper object 
                Dim myHelper As SAP2000v1.cHelper

                myHelper = New SAP2000v1.Helper

                'create SAP2000 object
                SAP2000Object = myHelper.CreateObject(ProgramPath)
            Catch ex As Exception
                MsgBox("Cannot start a new instance of the program.")
                ret = -1 : Return ret
            End Try
            'start SAP2000 application
            ret = SAP2000Object.ApplicationStart()
            If (ret <> 0) Then : MsgBox("Problem occured on :ApplicationStart") : Return ret : Exit Function : End If
        End If

        'Get a reference to cSapModel to access all OAPI classes and functions 
        SapModel = SAP2000Object.SapModel

        If FormInfo.HideSAP2000 = True Then ret = SAP2000Object.Hide                       'hide application
        If (ret <> 0) Then : MsgBox("Problem occured on :Hide model") : Return ret : Exit Function : End If

        ret = SapModel.File.OpenFile(SapFileName)     'open an existing file
        If (ret <> 0) Then : MsgBox("Problem occured on :OpenFile") : Return ret : Exit Function : End If

        Dim islocked As Boolean
        islocked = SapModel.GetModelIsLocked       'check if model is locked
        If islocked = True Then                    'Unlock model
            ret = SapModel.SetModelIsLocked(False)
            If (ret <> 0) Then : MsgBox("Problem occured on :Unlock model") : Return ret : Exit Function : End If
        End If
        '_____________________________________________________
        'set present units to KN-m
        ret = SapModel.SetPresentUnits(SAP2000v1.eUnits.kN_mm_C)
        If (ret <> 0) Then : MsgBox("Problem occured on :SetPresentUnits") : Return ret : Exit Function : End If
        'assign material property weight per unit volume
        Dim m As Double
        ret = SapModel.PropMaterial.GetWeightAndMass("A992Fy50", A992Fy50Weight, m)
        If (ret <> 0) Then : MsgBox("Problem occured on :PropMaterial.GetWeightAndMass") : Return ret : Exit Function : End If
        Return ret
    End Function
    Private Function InitilizePoints() As Integer
        '_____________________________________________________
        'get Point object data
        Dim PNumber As Integer
        Dim PNames() As String = Nothing
        '_____________________________________________________
        'get point object names
        ret = SapModel.PointObj.GetNameList(PNumber, PNames)
        If (ret <> 0) Then : errorlogprint("Problem occured on :PointObj.GetNamelist") : Return ret : Exit Function : End If ':stop
        ReDim Points(PNumber - 1)
        For i = 0 To PNumber - 1
            Points(i).PointName = PNames(i)
            '_____________________________________________________
            'get point coordinates
            ret = SapModel.PointObj.GetCoordCartesian(Points(i).PointName, Points(i).Xcoord, Points(i).YCoord, Points(i).Zcoord)
            If (ret <> 0) Then : errorlogprint("Problem occured on :GetCoordCartesian") : Return ret : Exit Function : End If
        Next i
        Return ret
    End Function
    Private Function InitilizeFrames() As Integer
        Dim FNumber As Integer
        Dim FNames() As String = Nothing
        '_____________________________________________________
        'get frame object names
        ret = SapModel.FrameObj.GetNameList(FNumber, FNames)
        If (ret <> 0) Then : errorlogprint("Problem occured on :GetNameList") : Return ret : Exit Function : End If
        ReDim Frames(FNumber - 1)
        For i = 0 To FNumber - 1
            Frames(i).FrameName = FNames(i)
            '_____________________________________________________
            'get names of points
            Dim FirstPoint As String = Nothing
            Dim SecondPoint As String = Nothing
            ret = SapModel.FrameObj.GetPoints(Frames(i).FrameName, FirstPoint, SecondPoint)
            If (ret <> 0) Then : errorlogprint("Problem occured on :FrameObj.GetPoints") : Return ret : Exit Function : End If
            Dim ind1 As Integer = Points.ToList().FindIndex(Function(c) c.PointName = FirstPoint)
            Dim ind2 As Integer = Points.ToList().FindIndex(Function(c) c.PointName = SecondPoint)
            Frames(i).FirstPointName = Points(ind1).PointName
            Frames(i).SecondPointName = Points(ind2).PointName
            Frames(i).FrameLenght = Math.Sqrt((Points(ind2).Xcoord - Points(ind1).Xcoord) ^ 2 + (Points(ind2).YCoord - Points(ind1).YCoord) ^ 2 + (Points(ind2).Zcoord - Points(ind1).Zcoord) ^ 2)
            '_____________________________________________________
            'get frame local axis angle
            Dim Advanced As Boolean = False
            ret = SapModel.FrameObj.GetLocalAxes(Frames(i).FrameName, Frames(i).LocalAxisAngle, Advanced)
            If (ret <> 0) Then : errorlogprint("Problem occured on :FrameObj.GetLocalAxes") : Return ret : Exit Function : End If
            '_____________________________________________________
            'get frame object groups
            Dim NumberGroups As Integer
            Dim Groups() As String = Nothing
            ret = SapModel.FrameObj.GetGroupAssign(Frames(i).FrameName, NumberGroups, Groups)
            If (ret <> 0) Then : errorlogprint("Problem occured on :GetGroupAssign") : Return ret : Exit Function : End If
            If NumberGroups = 1 Then
                errorlogprint("No group definition, Check group of frame ID:" & Frames(i).FrameName)
            End If
            If NumberGroups > 2 Then
                errorlogprint("More group definition than 1, Check group of frame ID:" & Frames(i).FrameName)
            End If
            For j = 0 To NumberGroups - 1
                If Groups(j) <> "All" Then
                    Frames(i).GroupName = Groups(j)
                End If
            Next j
            '_____________________________________________________
            'Get Frame design procedure
            ret = SapModel.FrameObj.GetDesignProcedure(Frames(i).FrameName, Frames(i).FrameDesignProcedure)
            If (ret <> 0) Then : errorlogprint("Problem occured on :GetDesignProcedure") : Return ret : Exit Function : End If
        Next i
        Return ret
    End Function

    Private Function InitilizeGroups() As Integer
        Dim FNumber As Integer
        Dim FNames() As String = Nothing
        Dim GNumber As Integer
        Dim GNames() As String = Nothing
        '_____________________________________________________
        'get Group names
        ret = SapModel.GroupDef.GetNameList(GNumber, GNames)
        If (ret <> 0) Then : errorlogprint("Problem occured on :GroupDef.GetNameList") : Return ret : Exit Function : End If

        ' Remove "All" from the array using LINQ
        GNames = GNames.ToList().Where(Function(item) item <> "ALL").ToArray()
        GNames = GNames.ToList().Where(Function(item) item <> "All").ToArray()
        GNumber = GNames.Length
        ReDim Groups(GNumber - 1)
        SteelFrameDesignGroupIDs = New List(Of Integer)
        For i = 0 To GNumber - 1
            Groups(i).GroupName = GNames(i)
            Dim ObjectType() As Integer = Nothing
            '_____________________________________________________
            'get group assignments
            ret = SapModel.GroupDef.GetAssignments(Groups(i).GroupName, FNumber, ObjectType, FNames)
            If (ret <> 0) Then : errorlogprint("Problem occured on :GroupDef.GetAssignments") : Return ret : Exit Function : End If
            If FNumber = 0 Then : errorlogprint("check group members of group:" & GNames(i)) : End If
            ReDim Groups(i).GroupObjectNames(FNumber - 1)
            ReDim Groups(i).GroupObjectTypes(FNumber - 1)

            Groups(i).GroupLength = 0
            For j = 0 To FNumber - 1
                Groups(i).GroupObjectNames(j) = FNames(j)
                Groups(i).GroupObjectTypes(j) = ObjectType(j)

            Next j
            For j = 1 To FNumber - 1
                If Groups(i).GroupObjectTypes(j) <> Groups(i).GroupObjectTypes(j - 1) Then
                    errorlogprint("Diffrent types of object please check group " & Groups(i).GroupName)
                    ret = -1
                    Return ret : Exit Function
                End If
            Next j

            For j = 0 To FNumber - 1
                If Groups(i).GroupObjectTypes(0) = ObjectType_.Frame Then
                    Dim FName As String = FNames(j)
                    Dim GFrames As IEnumerable(Of Frame_) = Frames.ToList().Where(Function(c) c.FrameName = FName)
                    Groups(i).GroupLength += GFrames.Sum(Function(c) c.FrameLenght)
                    If Groups(i).GroupDesignPocedure <> GFrames(0).FrameDesignProcedure And j > 0 Then
                        errorlogprint("Check design procedure of member " & GFrames(0).FrameName & " of  group:")
                        ret = -1
                        Return ret : Exit Function
                    End If
                    Groups(i).GroupDesignPocedure = GFrames(0).FrameDesignProcedure
                End If

            Next j

            If Groups(i).GroupObjectTypes(0) = ObjectType_.Frame Then
                If Groups(i).GroupDesignPocedure = DesignProcedure_.SteelFrameDesign Then
                    SteelFrameDesignGroupIDs.Add(i)

                End If
            End If
        Next i
        Return ret
    End Function
    Private Function InitilizeLoadCases() As Integer
        Dim NumberNames As Integer
        Dim MyName As String() = Nothing
        ret = SapModel.RespCombo.GetNameList(NumberNames, MyName)
        If (ret <> 0) Then : errorlogprint("Problem occured on :RespCombo.GetNameList") : Return ret : Exit Function : End If
        ComboNames.AllCombos = MyName.ToList()

        ret = SapModel.DesignSteel.GetComboStrength(NumberNames, MyName)
        If (ret <> 0) Then : errorlogprint("Problem occured on :DesignSteel.GetComboStrength") : Return ret : Exit Function : End If
        ComboNames.DesignSteelStrength = MyName.ToList()

        ret = SapModel.DesignSteel.GetComboDeflection(NumberNames, MyName)
        If (ret <> 0) Then : errorlogprint("Problem occured on :DesignSteel.GetComboDeflection") : Return ret : Exit Function : End If
        ComboNames.DesignSteelDeflection = MyName.ToList()

        '______________________________________________________
        'set combo selected for output
        For i = 0 To ComboNames.AllCombos.Count - 1

            ret = SapModel.Results.Setup.SetComboSelectedForOutput(ComboNames.AllCombos(i))
            If (ret <> 0) Then : errorlogprint("Problem occured on :SetComboSelectedForOutput") : Return ret : Exit Function : End If
        Next i
        Return ret
    End Function
    Private Function InitilizeSections() As Integer
        If FormInfo.UseDefinedSection = False Then
            ret = InitilizeSections_ReadXML()
            If (ret <> 0) Then : errorlogprint("Problem occured on :InitilizeSections_ReadXML") : Return ret : Exit Function : End If
            ret = InitilizeSections_Import()
            If (ret <> 0) Then : errorlogprint("Problem occured on :InitilizeSections_Import") : Return ret : Exit Function : End If
        Else
            ret = InitializeSections_ReadDefined()
        End If
        Return 0
    End Function
    Private Function InitilizeSections_ReadXML() As Integer

        'Dim xmldoc As New XmlDataDocument()
        Dim xmldoc As New XmlDocument()
        Dim xmlnode As XmlNodeList
        Dim i As Integer
        Dim ISections() As STEEL_I_SECTION
        Dim fs As New FileStream(SectionPropertyData, FileMode.Open, FileAccess.Read)
        xmldoc.Load(fs)
        xmlnode = xmldoc.GetElementsByTagName("STEEL_I_SECTION")
        ReDim ISections(xmlnode.Count - 1)
        For i = 0 To xmlnode.Count - 1
            ISections(i).SectionName = xmlnode(i).ChildNodes.Item(0).InnerText
            ISections(i).Designation = xmlnode(i).ChildNodes.Item(2).InnerText
            ISections(i).Depth = xmlnode(i).ChildNodes.Item(3).InnerText
            ISections(i).FlangeLength = xmlnode(i).ChildNodes.Item(4).InnerText
            ISections(i).FlangeTickness = xmlnode(i).ChildNodes.Item(5).InnerText
            ISections(i).WebTickness = xmlnode(i).ChildNodes.Item(6).InnerText
            ISections(i).KDES = xmlnode(i).ChildNodes.Item(7).InnerText
            ISections(i).Area = xmlnode(i).ChildNodes.Item(8).InnerText
            ISections(i).Imajor = xmlnode(i).ChildNodes.Item(9).InnerText
            ISections(i).PlasticModulusMajor = xmlnode(i).ChildNodes.Item(10).InnerText
            ISections(i).ShearAreaMajor = xmlnode(i).ChildNodes.Item(11).InnerText
            ISections(i).Iminor = xmlnode(i).ChildNodes.Item(12).InnerText
            ISections(i).PlasticModulusMinor = xmlnode(i).ChildNodes.Item(13).InnerText
            ISections(i).ShearAreaMinor = xmlnode(i).ChildNodes.Item(14).InnerText
            ISections(i).TorsionalConstant = xmlnode(i).ChildNodes.Item(15).InnerText
            ISections(i).SectionModulusMajorPos = xmlnode(i).ChildNodes.Item(16).InnerText
            ISections(i).SectionModulusMajorNeg = xmlnode(i).ChildNodes.Item(17).InnerText
            ISections(i).SectionModulusMinorPos = xmlnode(i).ChildNodes.Item(18).InnerText
            ISections(i).SectionModulusMinorNeg = xmlnode(i).ChildNodes.Item(19).InnerText
            ISections(i).RadiusofGyrationMajor = xmlnode(i).ChildNodes.Item(20).InnerText
            ISections(i).RadiusofGyrationMinor = xmlnode(i).ChildNodes.Item(21).InnerText
        Next
        WSections = ISections.ToList().Where(Function(c) c.Designation = "W").OrderBy(Function(c) c.Area)
        xmlnode = xmldoc.GetElementsByTagName("STEEL_PIPE")
        Dim Steel_Pipes() As STEEL_PIPE
        ReDim Steel_Pipes(xmlnode.Count - 1)
        For i = 0 To xmlnode.Count - 1
            Steel_Pipes(i).SectionName = xmlnode(i).ChildNodes.Item(0).InnerText
            Steel_Pipes(i).Designation = xmlnode(i).ChildNodes.Item(2).InnerText
            Steel_Pipes(i).Diameter = xmlnode(i).ChildNodes.Item(3).InnerText
            Steel_Pipes(i).Tickness = xmlnode(i).ChildNodes.Item(4).InnerText
            Steel_Pipes(i).Area = xmlnode(i).ChildNodes.Item(5).InnerText
            Steel_Pipes(i).Imajor = xmlnode(i).ChildNodes.Item(6).InnerText
            Steel_Pipes(i).PlasticModulusMajor = xmlnode(i).ChildNodes.Item(7).InnerText
            Steel_Pipes(i).ShearAreaMajor = xmlnode(i).ChildNodes.Item(8).InnerText
            Steel_Pipes(i).TorsionalConstant = xmlnode(i).ChildNodes.Item(9).InnerText
            Steel_Pipes(i).SectionModulusMajorPos = xmlnode(i).ChildNodes.Item(10).InnerText
            Steel_Pipes(i).SectionModulusMajorNeg = xmlnode(i).ChildNodes.Item(11).InnerText
            Steel_Pipes(i).RadiusofGyrationMajor = xmlnode(i).ChildNodes.Item(12).InnerText
        Next i
        PIPESections = Steel_Pipes.ToList().Where(Function(c) c.SectionName.Contains("PIPE")).OrderBy(Function(c) c.Area)
        HSSSections = Steel_Pipes.ToList().Where(Function(c) c.SectionName.Contains("HSS")).OrderBy(Function(c) c.Area)
        Return ret
    End Function
    Private Function InitilizeSections_Import()
        Dim SectionsName As String()
        If FormInfo.SectionListName = "PIPE" Then
            SectionsName = PIPESections.ToList().Select(Function(c) c.SectionName).ToArray()
        ElseIf FormInfo.SectionListName = "HSS" Then
            SectionsName = HSSSections.ToList().Select(Function(c) c.SectionName).ToArray()
        ElseIf formInfo.SectionListName = "W" Then
            SectionsName = WSections.ToList().Select(Function(c) c.SectionName).ToArray()
        Else
            errorlogprint("Problem occured on :SetAutoSelectSteel") : Return -1 : Exit Function
        End If
        For i = 0 To SectionsName.Count - 1
            'import new frame section property
            ret = SapModel.PropFrame.ImportProp(WSections(i).SectionName, "A992Fy50", SectionPropertyData, WSections(i).SectionName)
            If (ret <> 0) Then : errorlogprint(SectionsName(i) & " already defined and the section is added") : End If
        Next i

        'set new auto select list frame section property
        ret = SapModel.PropFrame.SetAutoSelectSteel("AUTO", SectionsName.Length, SectionsName)
        If (ret <> 0) Then : errorlogprint("AUTO already defined and the section is added") : ret = 0 : End If
        Return ret
    End Function

    Private Function InitializeSections_ReadDefined() As Integer
        Dim NumberofSections As Integer
        Dim SectionNames() As String = Nothing

        'get frame section property names
        ret = SapModel.PropFrame.GetNameList(NumberofSections, SectionNames)
        If (ret <> 0) Then
            errorlogprint("Problem occurred on: PropFrame.GetNameList")
            Return ret
        End If

        ' Initialize Steel_Pipes list
        Dim Steel_Pipes As New List(Of STEEL_PIPE)

        For i = 0 To SectionNames.Length - 1
            'get frame property type
            Dim PropType As eFramePropType
            ret = SapModel.PropFrame.GetTypeOAPI(SectionNames(i), PropType)
            If PropType = eFramePropType.Pipe Then
                Dim Steel_Pipe = New STEEL_PIPE()
                With Steel_Pipe
                    .SectionName = SectionNames(i)
                    Dim FileName As String = Nothing
                    Dim MatProp As String = Nothing
                    Dim Color As Long
                    Dim Notes As String = Nothing
                    Dim GUID As String = Nothing
                    'get frame section property data
                    ret = SapModel.PropFrame.GetPipe(.SectionName, FileName, MatProp, .Diameter, .Tickness, Color, Notes, GUID)
                    If (ret <> 0) Then
                        errorlogprint("Problem occurred on: GetPipe " & .SectionName)
                        Return ret
                    End If

                    ' Calculations based on properties
                    .Area = Math.PI * 0.25 * (.Diameter ^ 2 - (.Diameter - 2 * .Tickness) ^ 2)
                    .Imajor = Math.PI / 64 * (.Diameter ^ 4 - (.Diameter - 2 * .Tickness) ^ 4)
                    .PlasticModulusMajor = Math.PI / 32 * (.Diameter ^ 3 - (.Diameter - 2 * .Tickness) ^ 3)
                    .ShearAreaMajor = Math.PI * 0.25 * (.Diameter - 0.5 * .Tickness) ^ 2

                    ' Add to the list
                    Steel_Pipes.Add(Steel_Pipe)
                End With
            End If
        Next i
        PIPESections = Steel_Pipes.OrderBy(Function(c) c.Area)
        ' Additional processing or return if needed
        Return 0
    End Function

    Public Sub Evaluate(ByRef Member As Member_, ByRef iter_ As Integer)

        Dim Sect_Ind() As Integer = Member.DesignVariables
        Iter = iter_
        Call Setsection(Sect_Ind)
        Call Penalty(Member.Penalty, Sect_Ind)
        Member.CostValue = CostStProfile(Sect_Ind)
        Member.PenalizedCost = Member.CostValue * (1 + Member.Penalty) ^ 3
        iter_ = Iter
    End Sub
    Public Sub Setsection(ByRef Sect_Ind() As Integer)
        '_______________________________________________________________________________________________
        'check if model is locked
        If SapModel.GetModelIsLocked = True Then                'Unlock model
            ret = SapModel.SetModelIsLocked(False)
            If (ret <> 0) Then : errorlogprint("Problem occured on :Unlock model") : Stop : Exit Sub : End If
        End If
        '_______________________________________________________________________________________________
        'set frame steel section property
        For i = 0 To SteelFrameDesignGroupIDs.Count - 1
            Dim id As Integer = i
            Dim isec As Integer = SteelFrameDesignGroupIDs(id)
            ret = SapModel.FrameObj.SetSection(Groups(isec).GroupName, PIPESections(Sect_Ind(id)).SectionName, SAP2000v1.eItemType.Group)
            If (ret <> 0) Then : errorlogprint("Problem occured on :FrameObj.SetSection, Group:" & CStr(Groups(isec).GroupName) & " Section:" & CStr(PIPESections(Sect_Ind(id)).SectionName)) : Stop : Exit Sub : End If
        Next i
        Iter += 1
    End Sub
    Public Sub Analysis()
        '_______________________________________________________________________________________________
        'run model
        ret = SapModel.File.Save(FormInfo.FileList.SAP2000File)
        If (ret <> 0) Then : errorlogprint("Problem occured in :File.Save") : Exit Sub : End If
        ret = SapModel.Analyze.RunAnalysis
        If (ret <> 0) Then : errorlogprint("Problem occured on :RunAnalysis") : Exit Sub : End If
    End Sub
    Public Sub Design()
        '_______________________________________________________________________________________________
        'start Steel design
        If SteelFrameDesignGroupIDs.Count > 0 Then
            ret = SapModel.DesignSteel.SetCode(FormInfo.FrameInfo.SteelDesignCode)
            If (ret <> 0) Then : errorlogprint("Problem occured on :DesignSteel.SetCode") : Exit Sub : End If
            ret = SapModel.DesignSteel.StartDesign
            If (ret <> 0) Then : errorlogprint("Problem occured on :DesignSteel.StartDesign") : Exit Sub : End If
        End If
    End Sub

    Public Sub Penalty(ByRef Penalty As Double, ByRef Sect_Ind() As Integer)
        Call Analysis()
        Call Design()
        Call Penalty_PMM(Penalty, Sect_Ind)
    End Sub
    Private Sub Penalty_PMM(ByRef Penalty As Double, ByRef Sect_Ind() As Integer)
        Call ConsPMM()
        If FormInfo.CheckStructure = False Then Modifier_PMM(Sect_Ind)
        Dim Ratios As IEnumerable(Of Double) = Groups.ToList().Select(Function(c) c.PMMRatio)
        If Ratios.Max() > 1 Then Penalty += Ratios.Max() - 1
    End Sub


    Public Function CostStProfile(ByRef Sect_Ind)
        StructureWeight = 0
        For i = 0 To SteelFrameDesignGroupIDs.Count - 1
            StructureWeight += Groups(SteelFrameDesignGroupIDs(i)).GroupLength * PIPESections(Sect_Ind(i)).Area * A992Fy50Weight
        Next
        Return StructureWeight
    End Function

    Public Function CostSlab()
        Return 0
    End Function

    Public Function CostStud()
        Return 0
    End Function
    Public Sub ConsPMM()
        SAP2000_print.PMM_Ratios = New List(Of Double)
        For i = 0 To SteelFrameDesignGroupIDs.Count - 1
            Dim ID As Integer = SteelFrameDesignGroupIDs(i)
            Dim NumberItems As Integer
            Dim FrameName As String() = Nothing
            Dim Ratio As Double() = Nothing
            Dim RatioType As Integer() = Nothing
            Dim Location As Double() = Nothing
            Dim ComboName As String() = Nothing
            Dim ErrorSummary As String() = Nothing
            Dim WarningSummary As String() = Nothing
            Dim ItemType As SAP2000v1.eItemType = SAP2000v1.eItemType.Group
            ret = SapModel.DesignSteel.GetSummaryResults(Groups(ID).GroupName, NumberItems, FrameName, Ratio, RatioType, Location, ComboName, ErrorSummary, WarningSummary, ItemType)
            If (ret <> 0) Then : errorlogprint("Problem occured on :DesignSteel.GetSummaryResults") : Stop : Exit Sub : End If
            Groups(ID).PMMRatio = Ratio.Max()
            Dim ErrorMember = ErrorSummary.ToList().Where(Function(c) c <> "")
            If ErrorMember.Count > 0 Then Groups(ID).PMMRatio += 1 + ErrorMember.Count / NumberItems

            SAP2000_print.PMM_Ratios.Add(Groups(ID).PMMRatio)
            Dim DSectionAreas As List(Of Double) = New List(Of Double)
            Dim PropName(NumberItems - 1) As String
            For j = 0 To NumberItems - 1
                ret = SapModel.DesignSteel.GetDesignSection(FrameName(j), PropName(j))
                If (ret <> 0) Then : errorlogprint("Problem occured on :DesignSteel.GetDesignSection") : Stop : Exit Sub : End If
                Dim PName As String = PropName(j)
                Dim SectID As Integer = PIPESections.ToList().FindIndex(Function(c) c.SectionName = PName)
                DSectionAreas.Add(PIPESections(SectID).Area)
            Next j
            Dim AreaMax = DSectionAreas.Max()
            Dim IDmax As Integer = DSectionAreas.FindIndex(Function(c) c = AreaMax)
            Groups(ID).DesignSecName = PropName(IDmax)
            Groups(ID).DesignSecID = PIPESections.ToList().FindIndex(Function(c) c.SectionName = PropName(IDmax))

        Next i
    End Sub
    Private Sub Modifier_PMM(ByRef Sect_Ind() As Integer)
        For i = 0 To SteelFrameDesignGroupIDs.Count - 1
            Dim ID As Integer = SteelFrameDesignGroupIDs(i)
            If Groups(ID).PMMRatio > 1 Then Sect_Ind(i) = Sect_Ind(i) + CInt(0.5 * Math.Log(Groups(ID).PMMRatio) * PIPESections.Count) 'özel formül
            If Ub(i) < Sect_Ind(i) Then Sect_Ind(i) = Ub(i)
            If Lb(i) > Sect_Ind(i) Then Sect_Ind(i) = Lb(i)
        Next i
        Dim Ratios As IEnumerable(Of Double) = Groups.ToList().Select(Function(c) c.PMMRatio)
        If Ratios.Max() > 1 Then
            Call Setsection(Sect_Ind)
            Call Analysis()
            Call Design()
            Call ConsPMM()
        End If
    End Sub
    Private Sub UpdateJointDisp()
        Dim NumberNames As Integer
        Dim MyName() As String = Nothing
        'get load case names
        ret = SapModel.LoadCases.GetNameList(NumberNames, MyName)
        If (ret <> 0) Then : errorlogprint("SapModel.LoadCases.GetNameList") : Exit Sub : End If
        For i = 0 To NumberNames - 1
            ret = SapModel.Results.Setup.SetCaseSelectedForOutput(MyName(i))
            If (ret <> 0) Then : errorlogprint("SapModel.Results.Setup.SetCaseSelectedForOutput") : Exit Sub : End If
        Next i

        For i = 0 To Points.Count - 1
            Dim NumberResults As Integer
            Dim ItemType As SAP2000v1.eItemType = SAP2000v1.eItemType.Objects
            Dim Obj() As String = Nothing
            Dim Elm() As String = Nothing
            Dim LoadCase() As String = Nothing
            Dim StepType() As String = Nothing
            Dim StepNum() As Double = Nothing
            Dim U1() As Double = Nothing
            Dim U2() As Double = Nothing
            Dim U3() As Double = Nothing
            Dim R1() As Double = Nothing
            Dim R2() As Double = Nothing
            Dim R3() As Double = Nothing ' 
            '_________________________________________
            'get joint displacements
            ret = SapModel.Results.JointDispl(Points(i).PointName, ItemType, NumberResults, Obj, Elm, LoadCase, StepType, StepNum, U1, U2, U3, R1, R2, R3)
            If (ret <> 0) Then : errorlogprint("Problem occured on :Results.JointDispl") : Exit Sub : End If
            Points(i).PointDisp.LoadCaseName = LoadCase.ToList()
            Points(i).PointDisp.U1 = U1.ToList()
            Points(i).PointDisp.U2 = U2.ToList()
            Points(i).PointDisp.U3 = U3.ToList()
        Next i

    End Sub
    Public Sub Initilize_UBLB()
        '_______________________________________________________________________________________________
        'Assign Auto Sections
        Dim Members As IEnumerable(Of Frame_) = Frames.ToList().Where(Function(c) c.FrameDesignProcedure = DesignProcedure_.SteelFrameDesign)
        For Each Member In Members
            'Dim SteelBeamGroupID As Integer = Groups.ToList().FindIndex(Function(c) c.GroupFrames(0).GroupName = Frame.GroupName)
            ret = SapModel.FrameObj.SetSection(Member.FrameName, "AUTO", 0)
            If (ret <> 0) Then : errorlogprint("Problem occured on :FrameObj.SetSection: Auto") : Exit Sub : End If
        Next

        Call Analysis()
        Call Design()
        Call ConsPMM()
        Dim NofDesignVariables As Integer = SteelFrameDesignGroupIDs.Count
        ReDim Ub(NofDesignVariables - 1)
        ReDim Lb(NofDesignVariables - 1)
        Dim Sect_ind(NofDesignVariables - 1) As Integer
        For i = 0 To SteelFrameDesignGroupIDs.Count - 1
            Dim isec As Integer = SteelFrameDesignGroupIDs(i)
            Sect_ind(i) = Groups(isec).DesignSecID
        Next i
        Call UpdateJointDisp()
        For i = 0 To SteelFrameDesignGroupIDs.Count - 1
            Dim isec As Integer = SteelFrameDesignGroupIDs(i)
            Ub(i) = Groups(isec).DesignSecID + CInt(Math.Log(Groups(isec).PMMRatio + 0.01) * 0.05 * (PIPESections.Count - 1) + 0.23 * (PIPESections.Count - 1)) 'özel formül
            Lb(i) = Groups(isec).DesignSecID + CInt(Math.Log(Groups(isec).PMMRatio + 0.01) * 0.05 * (PIPESections.Count - 1) - 0.23 * (PIPESections.Count - 1)) 'özel formül
            If Ub(i) > PIPESections.Count - 1 Then Ub(i) = PIPESections.Count - 1
            If Lb(i) < 0 Then Lb(i) = 0
        Next i
    End Sub
    Private Function errorlogprint(ByVal msg As String)
        Dim sw As New StreamWriter(Path.GetDirectoryName(FormInfo.FileList.SAP2000File) & "\ErrorLog.txt", True)
        ' Write the error message to the file
        sw.WriteLine("Error message: " & msg)

        ' Close the StreamWriter object
        sw.Close()
        Return Nothing
    End Function
End Class
Public Class SAP2000_Print
    Public PMM_Ratios As List(Of Double)
End Class

﻿Public Structure Frame_
    Public FrameName As String
    Public FirstPointName As String
    Public SecondPointName As String
    Public FrameLenght As Double
    Public GroupName As String
    'Public FrameSection As STEEL_I_SECTION
    Public LocalAxisAngle As Double
    Public FrameDesignProcedure As DesignProcedure_
End Structure
Public Structure Area_
    Public AreaName As String
    Public GroupName As String
    Public Area As Double
End Structure
Public Structure Combinations_
    Public DesignSteelStrength As List(Of String)
    Public DesignSteelDeflection As List(Of String)
    Public DesignCompStrength As List(Of String)
    Public DesignCompDeflection As List(Of String)
    Public AllCombos As List(Of String)
End Structure
Public Enum DesignProcedure_
    Programdetermined = 0
    SteelFrameDesign = 1
    ConcreteFrameDesign = 2
    CompositeBeamDesign = 3
    SteelJoistDesign = 4
    NoDesign = 7
    CompositeColumnDesign = 13
End Enum
Public Enum ObjectType_
    Point = 1
    Frame
    Cable
    Tendon
    Area
    Solid
    Link
End Enum
Public Structure Point_
    Public PointName As String
    Public Xcoord As Double
    Public YCoord As Double
    Public Zcoord As Double
    Public PointDisp As LoadCaseDisp_
End Structure
Public Structure Story_
    Public StoryName As String
    Public StoryPointNames() As String
    Public StoryFrames() As Frame_
    Public StoryLevel As Double
    Public InterStoryDriftLimit As Double
    Public InterStoryDriftX As Double
    Public InterStoryDriftY As Double
    Public InterStoryDPenaltyX As Double
    Public InterStoryDPenaltyY As Double
End Structure
Public Structure Group_
    Public GroupName As String
    Public GroupObjectNames() As String
    Public GroupObjectTypes() As ObjectType_
    Public GroupLength As Double
    Public GroupSection As STEEL_I_SECTION
    Public GroupDesignPocedure As DesignProcedure_
    Public PMMRatio As Double
    Public DesignSecName As String
    Public DesignSecID As Integer
End Structure
Public Structure STEEL_I_SECTION
    Public SectionName As String
    Public Designation As String
    Public Depth As Double
    Public FlangeLength As Double
    Public FlangeTickness As Double
    Public WebTickness As Double
    Public KDES As Double
    Public Area As Double
    Public Imajor As Double
    Public PlasticModulusMajor As Double
    Public ShearAreaMajor As Double
    Public Iminor As Double
    Public PlasticModulusMinor As Double
    Public ShearAreaMinor As Double
    Public TorsionalConstant As Double
    Public SectionModulusMajorPos As Double
    Public SectionModulusMajorNeg As Double
    Public SectionModulusMinorPos As Double
    Public SectionModulusMinorNeg As Double
    Public RadiusofGyrationMajor As Double
    Public RadiusofGyrationMinor As Double
End Structure
Public Structure STEEL_PIPE
    Public SectionName As String '0
    Public Designation As String '2
    Public Diameter As Double ' 3
    Public Tickness As Double '4
    Public Area As Double '5
    Public Imajor As Double '6
    Public PlasticModulusMajor As Double '7
    Public ShearAreaMajor As Double '8
    Public TorsionalConstant As Double '9
    Public SectionModulusMajorPos As Double '10
    Public SectionModulusMajorNeg As Double '11
    Public RadiusofGyrationMajor As Double '12
End Structure

Public Structure Numbers_
    Public NumberofMembers As Integer
    Public NumberofPoints As Integer
    Public NumberofGroups As Integer
    Public NumberofStories As Integer
    Public NumberofSteelFrameDesignGroups As Integer
End Structure
Public Structure LoadCaseDisp_
    Public LoadCaseName As List(Of String)
    Public U1 As List(Of Double)
    Public U2 As List(Of Double)
    Public U3 As List(Of Double)
End Structure
Public Structure FormInfo_
    Public FileList As FileList_
    Public FrameInfo As FrameInfo_
    Public OptInfo As OptInfo_
    Public TimerInfo As TimerInfo
    Public BackUp As Boolean
    Public HideSAP2000 As Boolean
    Public CheckStructure As Boolean
    Public SectionListName As String
    Public UseDefinedSection As Boolean
End Structure
Public Structure FileList_
    Public SAP2000File As String
    Public OutputFile As String
End Structure
Public Structure FrameInfo_
    Public DispLimit As Double
    Public SteelDesignCode As String
End Structure
Public Structure OptInfo_
    Public MaxFuncEvaluation As Double
    Public MemorySize As Integer
    Public MemoryUpdateType As MemoryUpdateType_
    Public ClearDuplicates As Boolean
    Public HarmonySearch As HarmonySearch_
    Public BioGeography As BioGeography_
    Public Wolf As Wolf_
    Public HoneyBadger As HoneyBadger_
    Public OptimizationMethod As OptMethod_
    Public LevyFlight As Boolean
    Public TestWithMath As Boolean
End Structure
Public Structure HarmonySearch_
    Dim PAR As Double
    Dim HMCR As Double
    Dim PARChangeType As PAR_HMCR_ChangeType_
    Dim HMCRChangeType As PAR_HMCR_ChangeType_
    Dim ParVec() As Double
    Dim HMCRVec() As Double
End Structure
Public Structure BioGeography_
    Dim MutationRate As Double
    Dim Mu() As Double
    Dim Lamda() As Double
End Structure

Public Structure Wolf_
    Dim STEPA As Double
    Dim STEPB As Double
    Dim HKR As Integer
    Dim RAMX As Double
    Dim RAMN As Double
End Structure

Public Structure HoneyBadger_
    Dim beta As Double
    Dim C As Double
End Structure
Public Structure TimerInfo
    Public StartTime As String
    Public FinishTime As String
    Public TotalTime As String
    Public startDate As Date
End Structure
Public Structure ParameterGeneral_
    Public MaxFuncEvaluation As Double
    Public MemorySize As Integer
    Public MemoryUpdateType As MemoryUpdateType_
    Public ClearDuplicates As Boolean
    Public MethodName As OptMethod_
End Structure
Public Enum OptMethod_
    HarmornySearch = 0
    BioGBasedO = 1
    WhaleOpt = 2
    DandelionOpt = 3
    Wolf = 4
    HoneyBadger = 5
End Enum
Public Enum MemoryUpdateType_
    NoGreedyCurrent = 0
    NoGreedyRandom = 1
    NoGreedyWorst = 2
    GreedyCurrent = 3
    GreedyRandom = 4
    GreedyWorst = 5
End Enum
Public Enum PAR_HMCR_ChangeType_
    IStatic = 0
    Dynamic = 1
    Adaptive = 2
End Enum
Public Structure Member_
    Public DesignVariables() As Integer
    Public CostValue As Double
    Public Penalty As Double
    Public PenalizedCost As Double
End Structure
Public Structure History_
    Public Iter As Integer
    Public ILoop As Integer
    Public Cost As Double
    Public Penalty As Double
End Structure
'Public Enum eFramePropType_
'    I = 1
'    Channel = 2
'    T = 3
'    Angle = 4
'    DblAngle = 5
'    Box = 6
'    Pipe = 7
'    Rectangular = 8
'    Circle = 9
'    General = 10
'    DbChannel = 11
'    Auto = 12
'    SD = 13
'    Variable = 14
'    Joist = 15
'    Bridge = 16
'    Cold_C = 17
'    Cold_2C = 18
'    Cold_Z = 19
'    Cold_L = 20
'    Cold_2L = 21
'    Cold_Hat = 22
'    BuiltupICoverplate = 23
'    PCCGirderI = 24
'    PCCGirderU = 25
'    BuiltupIHybrid = 26
'    BuiltupUHybrid = 27
'    Concrete_L = 28
'    FilledTube = 29
'    FilledPipe = 30
'    EncasedRectangle = 31
'    EncasedCircle = 32
'    BucklingRestrainedBrace = 33
'    CoreBrace_BRB = 34
'    ConcreteTee = 35
'    ConcreteBox = 36
'    ConcretePipe = 37
'    ConcreteCross = 38
'    SteelPlate = 39
'    SteelRod = 40
'    PCCGirderSuperT = 41
'    Cold_Box = 42
'    Cold_I = 43
'    Cold_Pipe = 44
'    Cold_T = 45
'    Trapezoidal = 46
'End Enum
'Public Class Writing
'    Public Structure Filenames
'        Public SAP2000fileName As String
'        Public OutputFileName As String
'    End Structure

'    Public Sub OutputWriting(ByRef Path As String)
'        Dim doc As New XmlDocument()
'        Dim root As XmlNode = doc.DocumentElement
'        Dim Filenames As New Writing.Filenames
'        'Create a new node.
'        Dim elem As XmlElement = doc.CreateElement("SAP2000fileName")
'        elem.InnerText = Filenames.SAP2000fileName
'        'Add the node to the document.
'        root.AppendChild(elem)

'        'Create a new node.
'        elem = doc.CreateElement("OutputFileName")
'        elem.InnerText = Filenames.OutputFileName
'        'Add the node to the document.
'        root.AppendChild(elem)
'    End Sub
'End Class